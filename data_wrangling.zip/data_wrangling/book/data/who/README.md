The data in this folder is from here:
http://apps.who.int/gho/data/node.main.3?lang=en

Interactive graphic of the data:
http://gamapserver.who.int/gho/interactive_charts/mbd/life_expectancy/atlas.html
